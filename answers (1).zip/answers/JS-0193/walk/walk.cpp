#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	cout<<-1;
	return 0;
}

