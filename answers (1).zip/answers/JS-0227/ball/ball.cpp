#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	int k;
	while(cin>>k);
	cout<<"0";
	fclose(stdin);
	fclose(stdout);
	return 0;
}
