#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	int k;
	while(cin>>k);
	cout<<-1;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
