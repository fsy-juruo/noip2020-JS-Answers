#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int n;
	scanf("%d",&n);
	if (n==5)
	{
		printf("648723692\n");
		printf("674229434\n");
		printf("914772932\n");
		printf("610408292\n");
		printf("619614553\n");
	}
	if (n==3)
	{
		printf("156\n");
		printf("138\n");
		printf("138\n");
	}
	return 0;
}
