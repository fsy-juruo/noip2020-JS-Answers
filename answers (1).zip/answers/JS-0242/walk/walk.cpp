#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	printf("-1\n");
	return 0;
}
