#include<bits/stdc++.h>
#define ll long long
using namespace std;

int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cout<<0<<endl;
	return 0;
}

