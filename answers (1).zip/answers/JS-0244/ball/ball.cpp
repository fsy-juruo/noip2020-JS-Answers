#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	return 0;
}
