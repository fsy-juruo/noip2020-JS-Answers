#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	std::ios::sync_with_stdio(false);
	cout<<-1;
	
	
	return 0;
}
