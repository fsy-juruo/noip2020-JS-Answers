#include <iostream>
#include <cstdio>
using namespace std;

int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	//Here're some words.
	//I can't deal with the problem.
	//I can't even get one score!
	//It's like Hanoi.
	//But...
	//It's not a Hanoi.
	//It's more difficult.
	//Well...
    //Time's up.
	return 0;
}

