#include<bits/stdc++.h>
using namespace std;
int n,m;
int a1[25],a2[25],a3[25];
void move(int a,int b,int c,int cnt){
	for(int i=1;i<m;i++){
		
	}
}
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(i==1)	cin>>a1[m-j+1];
			if(i==2)	cin>>a2[m-j+1];
		}
	}
	
	return 0;
}
