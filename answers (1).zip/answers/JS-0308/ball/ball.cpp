#include <bits/stdc++.h>
#define ll int
#define F first
#define S second
#define INF 1000000000
#define LINF 1000000000000000000
using namespace std;
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	puts("0");
	return 0;
}
