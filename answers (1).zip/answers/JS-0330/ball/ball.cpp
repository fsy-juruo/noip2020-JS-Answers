#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout); 
	cout<<"6"<<endl<<"1 3"<<endl<< "2 3"<<endl<< "2 3"<<endl<<"3 1"<<endl<<"3 2" <<endl<<"3 2"; 
}
