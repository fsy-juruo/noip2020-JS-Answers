#include<bits/stdc++.h>
#define io_speed_up ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
const int MAXN=1e3+5;
const int INF=0x3f3f3f3f;
const int MOD=1e9+7;

int main()
{
	io_speed_up;
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);

	return 0;


