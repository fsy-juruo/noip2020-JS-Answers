#include<bits/stdc++.h>
#define io_speed_up ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
const int MAXN=1e5+5;
const int INF=0x3f3f3f3f;
const int MOD=1e9+7;
int n,k,w[MAXN],c[MAXN],d[MAXN];
int step[MAXN];
int main()
{
	io_speed_up;
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=k;k++) cin>>w[i];
	for(int i=1;i<=n;i++) cin>>c[i]>>d[i];
	cout<<-1<<endl
	
	return 0;
}
