#include <bits/stdc++.h>
using namespace std;

int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cout<<"6\n1 3\n2 3\n2 3\n3 1\n3 2\n3 2\n";
	return 0;
}
