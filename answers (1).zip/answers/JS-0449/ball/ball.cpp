#include <bits/stdc++.h>
#define REP(x,l,u) for(int x=(l);x<=(u);x++)
#define REV(x,u,l) for(int x=(u);x>=(l);x--)
using namespace std;

typedef long long LL;

int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	return 0;
}

