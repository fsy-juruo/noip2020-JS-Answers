#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	int a,b,c[100][100];
	cin>>a>>b;
	for (int i=0;i<a;i++)
	{
		for (int n=0;n<b;n++)
		{
			cin>>c[i][n];
		}
	}
	cout<<0<<endl;
	return 0;
}
