#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	int a,b,c,d;
	cin>>a>>b;
	for (int i=0;i<b;i++)
	{
		cin>>c;
	}
	for (int i=0;i<a;i++)
	{
		cin>>c>>d;
	}
	cout<<-1<<endl;
	return 0;
}
