#include<bits/stdc++.h>
using namespace std;
int n,k,a;
int main()
{
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=k;i++)
	{
		scanf("%d",&a);
	}
	for(int i=1;i<=2*n;i++)
	{
		scanf("%d",&a);
	}
	printf("-1\n");
	return 0;
}
