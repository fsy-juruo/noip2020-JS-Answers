#include<bits/stdc++.h>
#define pb push_back
#define rep(i,n) for(int i=0;i<n;i++)
#define forn(i,a,b) for(int i=a;i<=b;i++)
#define all(a) a.begin(),a.end()
using namespace std;
typedef long long ll;
typedef vector<int> vi;
int main()
{
    freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
    cout<<-1<<endl;
	return 0;
}

