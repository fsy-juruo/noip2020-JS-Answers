#include<bits/stdc++.h>
using namespace std;
int n,m,a,b,c;
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)cin>>a>>b>>c;
	cout<<4<<endl;
	cout<<1<<' '<<3<<endl;
	cout<<2<<' '<<3<<endl;
	cout<<3<<' '<<1<<endl;
	cout<<3<<' '<<2<<endl;
	return 0;
}
