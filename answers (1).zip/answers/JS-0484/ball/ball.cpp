#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("ball.in","r",stdin);
    freopen("ball.out","w",stdout);
    return 0;
}
/*
  REMEMBER to init vals
  REMEMBER to check IO
  REMEMBER to compile before submitting
*/
