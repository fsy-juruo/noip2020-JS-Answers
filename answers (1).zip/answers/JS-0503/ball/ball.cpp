#include <bits/stdc++.h>
using namespace std;
int n, m;
int main()
{
	//time_t start_time = clock();
	freopen("ball.in", "r", stdin);
	freopen("ball.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin >> n >> m;
	cout << 0 << endl;
	return 0;
	//cerr << "Time used: " << clock() - start_time << endl;
	return 0;
}

