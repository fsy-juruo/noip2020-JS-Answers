#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen("string.out", "w", stdout);
	cout << "8" << endl << "9" << endl << 16;
	return 0;
}
