#include<bits/stdc++.h>
using namespace std;
#define Sf scanf
#define Pf printf
#define ll long long
#define Pii pair<int,int>
#define P2 pair
#define Sz size
#define Vct vector
#define Pb push_back
#define Cb make_pair
#define Fi first
#define Se second
#define Ins insert
#define Que queue
#define Fr front
#define Psh push
#define Pp pop
int main()
{
	return 0;
}
