#include <bits/stdc++.h>

using namespace std;
int alpha[27];
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int n;
	cin >> n;
	while (n--){
	    string s;
	    cin >> s;
	    cout << s.size() *2;
	}
	return 0;
}
