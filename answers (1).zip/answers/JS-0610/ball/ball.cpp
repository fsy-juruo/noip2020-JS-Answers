#include<bits/stdc++.h>
using namespace std;

signed main(){
	freopen("ball.in","r",stdin); freopen("ball.out","w",stdout);
	puts("0");
	fclose(stdin); fclose(stdout);
	return 0;
}
