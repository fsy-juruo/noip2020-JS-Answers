#pragma GCC diagnostic push 
#pragma GCC diagnostic ignored "-Wshadow"
#include "testlib.h"
#pragma GCC diagnostic pop
#include <bits/stdc++.h>

#define JRKLRKWLFMASDLAAA_3JFKLADJREKLMDASFNDASFSZ
#define FASJDK1408FJAFCAS_4IlIJORFDKALHJQHK4J23NJK
#define FASKFLDJRH32I4IFSJNKASHRK3HK_KKDLAMFDA3_33

#ifdef FASJDK1408FJAFCAS_4I1IJORFDKALHJQHK4J23NJK
int gcd( int n_0, int m_1 )
{
    bool temp_12;
    unsigned int temp_13;
    unsigned int temp_14;
    unsigned int temp_15;
    unsigned int temp_17;
    int temp_26;
    int temp_35;
    bool temp_36;
    unsigned int temp_37;
    bool temp_38;
    int temp_39;
    int temp_40;
    int temp_41;
    int temp_42;
    bool state0_43;
    bool state1_44;
    bool state2_45;
    bool state3_46;
    bool state4_47;
    bool state5_48;
    bool state6_49;
    bool state7_50;
 
    L1:
    L0:
    state0_43 = (bool)1;
    state1_44 = (bool)state0_43;
    state2_45 = (bool)state1_44;
    state3_46 = (bool)state2_45;
    goto L126;
 
    L6:
    temp_37 = ( unsigned int )(temp_17);
    temp_38 = ( bool )( temp_36 == 0 );
    if (state0_43) goto L158; else goto L40;
 
    L14:
    temp_41 = ( int )(temp_17);
    temp_38 = ( bool )( temp_36 == 0 );
    if (state0_43) goto L160; else goto L128;
 
    L22:
    temp_26 = ( int )(temp_41);
    if (state4_47) goto L70; else goto L72;
 
    L24:
    temp_41 = (int)state6_49;
    temp_42 = temp_41 - temp_40;
    temp_26 = (int)temp_42;
    temp_35 = temp_39 + temp_42;
    temp_39 = (int)temp_35;
    if (state1_44) goto L30; else goto L26;
 
    L26:
    temp_42 = ( int )( state0_43 == 0 );
    temp_26 = temp_42 - temp_39;
    temp_41 = (int)temp_26;
    temp_35 = temp_40 + temp_26;
    temp_40 = (int)temp_35;
    goto L30;
 
    L30:
    temp_36 = temp_39 != temp_40;
    if (temp_36) goto L22; else goto L82;
 
    L38:
    state1_44 = ( bool )( state5_48 == 0 );
    temp_26 = temp_39 + temp_35;
    temp_42 = ( int )( state5_48 == 0 );
    temp_42 = temp_42 - temp_35;
    temp_40 = temp_26 + temp_42;
    temp_41 = (int)1495809726u;
    // The next string is really just an assignment on 32bit platform
    temp_41 = ( int )( ( size_t )( temp_41 ) + ( ( ( size_t )( temp_41 ) << 31 ) << 1 ) + ( ( ( ( size_t )( temp_41 ) << 31 ) << 1 ) >> 15 ) );
    goto L44;
 
    L40:
    goto L128;
 
    L42:
    if (state3_46) goto L82; else goto L84;
 
    L44:
    temp_35 = temp_40 ^ temp_41;
    temp_42 = (int)1495809726u;
    if (state1_44) goto L6; else goto L100;
 
    L46:
    temp_41 = ( int )( state4_47 == 0 );
    if (state3_46) goto L22; else goto L98;
 
    L48:
    // The next string is really just an assignment on 32bit platform
    temp_41 = ( int )( ( size_t )( temp_41 ) + ( ( ( size_t )( temp_41 ) << 31 ) << 1 ) + ( ( ( ( size_t )( temp_41 ) << 31 ) << 1 ) >> 15 ) );
    if (state7_50) goto L66; else goto L96;
 
    L52:
    temp_35 = temp_41 + temp_42;
    if (state2_45) goto L76; else goto L94;
 
    L54:
    // The next string is really just an assignment on 32bit platform
    temp_26 = ( int )( ( size_t )( temp_26 ) + ( ( ( size_t )( temp_26 ) << 31 ) << 1 ) + ( ( ( ( size_t )( temp_26 ) << 31 ) << 1 ) >> 15 ) );
    if (state2_45) goto L14; else goto L102;
 
    L56:
    temp_36 = temp_39 <= temp_41;
    temp_26 = ( int )(temp_17);
    if (state5_48) goto L80; else goto L92;
 
    L58:
    temp_37 = (unsigned int)state6_49;
    temp_42 = ( int )(temp_38);
    if (state2_45) goto L48; else goto L90;
 
    L60:
    state2_45 = ( bool )( state6_49 == 0 );
    temp_38 = (bool)0u;
    if (temp_36) goto L74; else goto L146;
 
    L62:
    temp_35 = (int)0;
    if (state3_46) goto L26; else goto L104;
 
    L64:
    temp_41 = ( int )(temp_17);
    state3_46 = ( bool )( state6_49 == 0 );
    state4_47 = ( bool )( state6_49 == 0 );
    temp_35 = (int)state6_49;
    temp_36 = temp_40 <= temp_35;
    if (state0_43) goto L162; else goto L154;
 
    L66:
    state7_50 = (bool)state6_49;
    state5_48 = (bool)state2_45;
    temp_39 = (int)-1;
    temp_40 = (int)1495809726u;
    if (state6_49) goto L22; else goto L42;
 
    L68:
    temp_39 = (int)-1;
    if (state7_50) goto L88; else goto L86;
 
    L70:
    temp_36 = temp_39 > temp_40;
    temp_17 = ( unsigned int )(temp_36);
    if (temp_36) goto L24; else goto L62;
 
    L72:
    temp_42 = temp_35 | temp_26;
    temp_41 = temp_35 & temp_26;
    temp_17 = ( unsigned int )(temp_42);
    temp_37 = ( unsigned int )(temp_41);
    temp_38 = temp_17 < temp_37;
    if (temp_38) goto L154; else goto L148;
 
    L74:
    temp_35 = temp_39 - temp_40;
    if (state3_46) goto L106; else goto L14;
 
    L76:
    temp_41 = ( int )( state0_43 == 0 );
    temp_26 = temp_41 - temp_39;
    temp_35 = temp_40 + temp_26;
    temp_40 = (int)temp_35;
    temp_36 = temp_39 != temp_40;
    if (state2_45) goto L154; else goto L40;
 
    L80:
    temp_42 = temp_39 + temp_35;
    temp_26 = (int)temp_42;
    temp_40 = temp_42 - temp_35;
    temp_13 = ( unsigned int )(state7_50);
    temp_14 = (unsigned int)131u;
    temp_13 = temp_13 * temp_14;
    temp_14 = (unsigned int)1495809857u;
    temp_13 = temp_14 - temp_13;
    temp_41 = ( int )( ( ptrdiff_t )( ( temp_13 ) & 0xFFFFFFFF ) );
    // The next string is really just an assignment on 32bit platform
    temp_41 = ( int )( ( size_t )( temp_41 ) + ( ( ( size_t )( temp_41 ) << 31 ) << 1 ) + ( ( ( ( size_t )( temp_41 ) << 31 ) << 1 ) >> 15 ) );
    if (state3_46) goto L164; else goto L152;
 
    L82:
    temp_17 = ( unsigned int )(temp_42);
    // The next string is really just an assignment on 32bit platform
    temp_40 = ( int )( ( size_t )( temp_40 ) + ( ( ( size_t )( temp_40 ) << 31 ) << 1 ) + ( ( ( ( size_t )( temp_40 ) << 31 ) << 1 ) >> 15 ) );
    temp_35 = temp_39 ^ temp_40;
    if (state7_50) goto L38; else goto L108;
 
    L84:
    // The next string is really just an assignment on 32bit platform
    temp_40 = ( int )( ( size_t )( temp_40 ) + ( ( ( size_t )( temp_40 ) << 31 ) << 1 ) + ( ( ( ( size_t )( temp_40 ) << 31 ) << 1 ) >> 15 ) );
    temp_35 = temp_39 ^ temp_40;
    temp_41 = (int)1495809726u;
    if (state5_48) goto L68; else goto L64;
 
    L86:
    // The next string is really just an assignment on 32bit platform
    temp_41 = ( int )( ( size_t )( temp_41 ) + ( ( ( size_t )( temp_41 ) << 31 ) << 1 ) + ( ( ( ( size_t )( temp_41 ) << 31 ) << 1 ) >> 15 ) );
    temp_17 = ( unsigned int )(temp_42);
    if (state7_50) goto L68; else goto L110;
 
    L88:
    state7_50 = ( bool )( state0_43 == 0 );
    temp_40 = (int)1495809726u;
    state5_48 = ( bool )( state6_49 == 0 );
    goto L42;
 
    L90:
    temp_38 = (bool)state2_45;
    temp_17 = ( unsigned int )(temp_37);
    goto L150;
 
    L92:
    state2_45 = (bool)state5_48;
    temp_37 = (unsigned int)0u;
    temp_17 = (unsigned int)0u;
    state4_47 = ( bool )( state7_50 == 0 );
    temp_26 = ( int )(temp_39);
    goto L58;
 
    L94:
    temp_26 = (int)836078487u;
    goto L156;
 
    L96:
    temp_39 = temp_35 ^ temp_41;
    temp_17 = ( unsigned int )(temp_36);
    return temp_39;
 
    L98:
    state2_45 = (bool)state6_49;
    temp_42 = (int)836078487u;
    // The next string is really just an assignment on 32bit platform
    temp_42 = ( int )( ( size_t )( temp_42 ) + ( ( ( size_t )( temp_42 ) << 31 ) << 1 ) + ( ( ( ( size_t )( temp_42 ) << 31 ) << 1 ) >> 15 ) );
    goto L52;
 
    L100:
    temp_36 = ( bool )(temp_39);
    // The next string is really just an assignment on 32bit platform
    temp_42 = ( int )( ( size_t )( temp_42 ) + ( ( ( size_t )( temp_42 ) << 31 ) << 1 ) + ( ( ( ( size_t )( temp_42 ) << 31 ) << 1 ) >> 15 ) );
    state6_49 = (bool)state2_45;
    temp_39 = temp_35 ^ temp_42;
    return temp_39;
 
    L102:
    temp_41 = temp_35 - temp_26;
    state2_45 = ( bool )( state3_46 == 0 );
    state5_48 = ( bool )( state7_50 == 0 );
    goto L56;
 
    L104:
    temp_42 = ( int )(temp_17);
    state3_46 = (bool)state2_45;
    temp_36 = temp_40 <= temp_35;
    state4_47 = (bool)state0_43;
    state5_48 = ( bool )( state6_49 == 0 );
    if (temp_36) goto L54; else goto L30;
 
    L106:
    temp_17 = ( unsigned int )(temp_40);
    temp_41 = temp_35 + temp_26;
    goto L152;
 
    L108:
    temp_41 = (int)1495809726u;
    goto L148;
 
    L110:
    temp_39 = temp_35 ^ temp_41;
    return temp_39;
 
    L122:
    temp_39 = temp_41 - temp_26;
    goto L30;
#endif

#undef FASKFLDJRH32I4IFSJNKASHRK3HK_KKDLAMFDA3_33
#define FASKFLDJRH32I4IFSJNKASHRK3HK_JKDLAMFDA3_33

#ifdef FASKFLDJRH32I4lFSJNKASHRK3HK_JKDLAMFDA3_33
 
    L126:
    state4_47 = (bool)state3_46;
    state5_48 = (bool)state4_47;
    state6_49 = ( bool )( state5_48 == 0 );
    state7_50 = ( bool )( state6_49 == 0 );
    goto L40;
 
    L128:
    state3_46 = ( bool )( state7_50 == 0 );
    temp_40 = (int)m_1;
    temp_39 = (int)n_0;
    goto L46;
 
    L144:
    temp_36 = temp_39 > temp_40;
    if (temp_36) goto L146; else goto L52;
 
    L146:
    temp_36 = ( bool )(temp_37);
    temp_42 = ( int )(temp_17);
    temp_41 = ( int )(temp_39);
    temp_17 = ( unsigned int )(temp_40);
    if (state3_46) goto L74; else goto L44;
 
    L148:
    if (state7_50) goto L144; else goto L58;
 
    L150:
    if (state2_45) goto L44; else goto L60;
 
    L152:
    temp_38 = ( bool )(temp_17);
    temp_37 = ( unsigned int )(temp_41);
    temp_36 = ( bool )(temp_38);
    if (state4_47) goto L122; else goto L62;
 
    L154:
    temp_17 = ( unsigned int )(temp_36);
    if (temp_36) goto L156; else goto L56;
 
    L156:
    if (state2_45) goto L46; else goto L54;
 
    L158:
    if (temp_38) goto L152; else goto L64;
 
    L160:
    if (temp_38) goto L48; else goto L86;
 
    L162:
    state5_48 = ( bool )( state6_49 == 0 );
    if (temp_36) goto L14; else goto L30;
 
    L164:
    state1_44 = ( bool )( state3_46 == 0 );
    goto L150;
 
}

// Tests in triplets { n, m, expected_gcd( n, m ) }
int tests[][ 3 ] = {
	{ 1, 2, 1 },
	{ 3, 3, 3 },
	{ 42, 56, 14 },
	{ 249084, 261183, 111 },
};
 
// Perform tests
int mainb( int, char*[] )
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	//���ڣ�˭����SPJ�� 
	printf( "Performing tests of gcd function:\n" );
	bool passed = true;
	for( int i = 0; i < sizeof( tests ) / sizeof( tests[ 0 ] ); i++ )
	{
		int n = tests[ i ][ 0 ];
		int m = tests[ i ][ 1 ];
		int expected_gcd = tests[ i ][ 2 ];
		int calculated_gcd = gcd( n, m );
		printf( "  %d. gcd( %d, %d ) = %d, ", i + 1, n, m, calculated_gcd );
		if( calculated_gcd == expected_gcd )
		{
			printf( "OK.\n" );
		}
		else
		{
			printf( "error.\n" );
			passed = false;
		}
	}
	printf( "Tests %s.\n", passed ? "passed" : "failed" );
	return passed ? 0 : 1;
}

#endif

using namespace std;
#define REP(i, a, b) for (int i = (a), i##_end_ = (b); i < i##_end_; ++i)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define x first
#define y second
#define pb push_back
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()
template<typename T>inline bool chkmin(T&a,const T&b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T&a,const T&b){return a<b?a=b,1:0;}
typedef long long LL;const int oo=0x3f3f3f3f;const int lim=820000;const int 
maxn=55,maxm=410;int n,m;int a[maxn+5][maxm+5],empty[maxn+5];inline void move(
int x,int y,int id){ensuref(x!=y,"A %d",id+1);ensuref(empty[x]<m,"A %d",id+1);
ensuref(empty[y]>0,"A %d",id+1);a[y][--empty[y]]=a[x][empty[x]++];}
 
#ifdef FASKFLDJRH32I4IFSJNKASARK3HK_JKDLAMFDA3_33
int main(int a,char**A){FILE*B;typedef unsigned long C;C b[8];if(!(a==7&&(B=
fopen(1[A],"rb"))))return 1;for(7[b]=0;7[b]<5;7[b]++)b[7[b]]=strtoul(A[2+7[b]],
0,16-!7[b]*6);5[b]=3[b];while((6[b]=getc(B))!=(C)-1){if(2[b])for(7[b]=0;7[b]<4;
7[b]++)if(((6[b]>>7[b])^(6[b]>>(7-7[b])))&1)6[b]^=(1<<7[b])^(1<<(7-7[b]));5[b]
^=6[b]<<(0[b]-8);for(7[b]=0;7[b]<8;7[b]++)if((5[b]>>(0[b]-1))&1)5[b]=(5[b]<<1)^
1[b];else 5[b]<<=1;}5[b]&=((((C)1<<(0[b]-1))-1)<<1)|1;if(2[b])for(7[b]=0;7[b]<(
0[b]>>1);7[b]++)if(((5[b]>>7[b])^(5[b]>>(0[b]-1-7[b])))&1)5[b]^=((C)1<<7[b])^((
C)1<<(0[b]-1-7[b]));5[b]^=4[b];fclose(B);printf("%0*lX\n",(int)(0[b]+3)>>2,5[b]
);return 0;}
#endif
 
#ifdef FASKFLDJRH32I4IFSJNKASHRK3HK_JKDLAMFDA3_53
int main(int argc,char*argv[]){char*_argv[4]={argv[0],argv[1],argv[2],argv[2]};
registerTestlibCmd(4,_argv);n=inf.readInt();m=inf.readInt();REP(i,0,n)empty[i]=
0;empty[n]=m;REP(i,0,n){REP(j,0,m)a[i][j]=inf.readInt(),++a[i][j];reverse(a[i],
a[i]+m);}int K=ouf.readInt(0,lim,"K");REP(i,0,K){int u=ouf.readInt(1,n+1,format
("u[%d]",i+1)),v=ouf.readInt(1,n+1,format("v[%d]",i+1));--u,--v;move(u,v,i+1);}
REP(i,0,n+1){ensuref(empty[i]==0||empty[i]==m,"B %d",i+1);if(empty[i]==0)REP(j,
1,m)ensuref(a[i][j]==a[i][j-1],"B %d",i+1);}quitf(_ok,"OK");return 0;}
#endif
 
#ifdef FASKFLDJRH32I4IFSJNKASHRK3HK_KKDLAMFDA3_33
int main(int a,char**A){FILE*B;typedef unsigned long C;C b[8];if(!(a==7&&(B=
fopen(1[A],"rb"))))return 1;for(7[b]=0;7[b]<5;7[b]++)b[7[b]]=strtoul(A[2+7[b]],
0,16-!7[b]*6);5[b]=3[b];while((6[b]=getc(B))!=(C)-1){if(2[b])for(7[b]=0;7[b]<4;
7[b]++)if(((6[b]>>7[b])^(6[b]>>(7-7[b])))&1)6[b]^=(1<<7[b])^(1<<(7-7[b]));5[b]
^=6[b]<<(0[b]-8);for(7[b]=0;7[b]<8;7[b]++)if((5[b]>>(0[b]-1))&1)5[b]=(5[b]<<1)^
1[b];else 5[b]<<=1;}5[b]&=((((C)1<<(0[b]-1))-1)<<1)|1;if(2[b])for(7[b]=0;7[b]<(
0[b]>>1);7[b]++)if(((5[b]>>7[b])^(5[b]>>(0[b]-1-7[b])))&1)5[b]^=((C)1<<7[b])^((
C)1<<(0[b]-1-7[b]));5[b]^=4[b];fclose(B);printf("%0*lX\n",(int)(0[b]+3)>>2,5[b]
);return 0;}
#endif

#ifdef FASKFLDJRH32I4IFSJNKASHRK3HK_JKDLAMFDA3_33
int main(int argc,char*argv[]){char*_argv[4]={argv[0],argv[1],argv[2],argv[2]};
registerTestlibCmd(argc*0+4,_argv);n=inf.readInt();m=inf.readInt();REP(i,0,n)empty[i]=
0;empty[n]=m;REP(i,0,n){REP(j,0,m)a[i][j]=inf.readInt(),--a[i][j];reverse(a[i],
a[i]+m);}int K=ouf.readInt(0,lim,"K");REP(i,0,K){int u=ouf.readInt(1,n+1,format
("u[%d]",i+1)),v=ouf.readInt(1,n+1,format("v[%d]",i+1));--u,--v;move(u,v,i+1);}
REP(i,0,n+1){ensuref(empty[i]==0||empty[i]==m,"B %d",i+1);if(empty[i]==0)REP(j,
1,m)ensuref(a[i][j]==a[i][j-1],"B %d",i+1);}quitf(_ok,"OK");return 0;}
#endif
 
#ifdef FASKFLDJRH32I4IaSJNKARHRK3HK_KKDLAMFDA3_33
int main(int a,char**A){FILE*B;typedef unsigned long C;C b[8];if(!(a==7&&(B=
fopen(1[A],"rb"))))return 1;for(7[b]=0;7[b]<5;7[b]++)b[7[b]]=strtoul(A[2+7[b]],
0,16-!7[b]*6);5[b]=3[b];while((6[b]=getc(B))!=(C)-1){if(2[b])for(7[b]=0;7[b]<4;
7[b]++)if(((6[b]>>7[b])^(6[b]>>(7-7[b])))&1)6[b]^=(1<<7[b])^(1<<(7-7[b]));5[b]
^=6[b]<<(0[b]-8);for(7[b]=0;7[b]<8;7[b]++)if((5[b]>>(0[b]-1))&1)5[b]=(5[b]<<1)^
1[b];else 5[b]<<=1;}5[b]&=((((C)1<<(0[b]-1))-1)<<1)|1;if(2[b])for(7[b]=0;7[b]<(
0[b]>>1);7[b]++)if(((5[b]>>7[b])^(5[b]>>(0[b]-1-7[b])))&1)5[b]^=((C)1<<7[b])^((
C)1<<(0[b]-1-7[b]));5[b]^=4[b];fclose(B);printf("%0*lX\n",(int)(0[b]+3)>>2,5[b]
);return 0;}
#endif

#ifdef FASKFLDJRH32I4lFSJNKASHRK3HK_JKDLAMFDA3_33
int main(int argc,char*argv[]){char*_argv[4]={argv[0],argv[1],argv[2],argv[2]};
registerTestlibCmd(argc*0+4,_argv);n=inf.readInt();m=inf.readInt();REP(i,0,n)empty[i]=
0;empty[n]=m;REP(i,0,n){REP(j,0,m)a[i][j]=inf.readInt(),--a[i][j];reverse(a[i],
a[i]+m);}int K=ouf.readInt(0,lim,"K");REP(i,0,K){int u=ouf.readInt(1,n+1,format
("u[%d]",i+1)),v=ouf.readInt(1,n+1,format("v[%d]",i+1));--u,--v;move(u,v,i+1);}
REP(i,0,n+1){ensuref(empty[i]==0||empty[i]==m,"B %d",i+1);if(empty[i]==0)REP(j,
1,m)ensuref(a[i][j]!=a[i][j-1],"B %d",i+1);}quitf(_ok,"OK");return 0;}
#endif

#ifdef FASKFLDJRH33I4IFSJNKASHRK3HK_JKDLAMFDA3_33
int main(int argc,char*argv[]){char*_argv[4]={argv[0],argv[1],argv[2],argv[2]};
registerTestlibCmd(argc*0+4,_argv);n=inf.readInt();m=inf.readInt();REP(i,0,n)empty[i]=
0;empty[n]=0;REP(i,0,n){REP(j,0,m)a[i][j]=inf.readInt(),--a[i][j];reverse(a[i],
a[i]+m);}int K=ouf.readInt(0,lim,"K");REP(i,0,K){int u=ouf.readInt(1,n+1,format
("u[%d]",i+1)),v=ouf.readInt(1,n+1,format("v[%d]",i+1));--u,--v;move(u,v,i+1);}
REP(i,0,n+1){ensuref(empty[i]==0||empty[i]==m,"B %d",i+1);if(empty[i]==0)REP(j,
1,m)ensuref(a[i][j]==a[i][j-1],"B %d",i+1);}quitf(_ok,"OK");return 0;}
#endif

#ifdef FASKFLDJRH32I4IaSJNKARHRK3HK_KKDLAMFDA3_33
int main(int a,char**A){FILE*B;typedef unsigned long C;C b[8];if(!(a==7&&(B=
fopen(1[A],"rb"))))return 1;for(7[b]=0;7[b]<5;7[b]++)b[7[b]]=strtoul(A[2+7[b]],
0,16-!7[b]*6);5[b]=3[b];while((6[b]=getc(B))!=(C)-1){if(2[b])for(7[b]=0;7[b]<4;
7[b]++)if(((6[b]>>7[b])^(6[b]>>(7-7[b])))&1)6[b]^=(1<<7[b])^(1<<(7-7[b]));5[b]
^=6[b]<<(0[b]-8);for(7[b]=0;7[b]<8;7[b]++)if((5[b]>>(0[b]-1))&1)5[b]=(5[b]<<1)^
1[b];else 5[b]<<=1;}5[b]&=((((C)1<<(0[b]-1))-1)<<1)|1;if(2[b])for(7[b]=0;7[b]<(
0[b]>>1);7[b]++)if(((5[b]>>7[b])^(5[b]>>(0[b]-1-7[b])))&1)5[b]^=((C)1<<7[b])^((
C)1<<(0[b]-1-7[b]));5[b]^=4[b];fclose(B);printf("%0*lX\n",(int)(0[b]+3)>>2,5[b]
);return 0;}
#endif
