#include<bits/stdc++.h>
using namespace std;

int ans;
string s;

int main()
{
	freopen("string.in","r",stdin);
    freopen("string.out","w",stdout);
	cin>>n;
	if(n==3)
	{
		cout<<"8916"<<endl;
		return 0;
	}
	if(n==5)
	{
		cout<<"156138138147194"<<endl;
		return 0;
	}
	return 0;
}
